# Guía de Conexión del Registro a Base de Datos

## ✅ Cambios Realizados

### 1. **Archivo: `php/auth/register.php`**
- ✓ Actualizado para trabajar con la tabla `usuarios_alborada`
- ✓ Campos procesados: `fullname`, `email`, `phone`, `password`
- ✓ Hash seguro de contraseñas con `PASSWORD_DEFAULT`
- ✓ Validación de email único
- ✓ Validación de contraseña (mínimo 6 caracteres)
- ✓ Respuesta JSON con mensajes de éxito/error
- ✓ Redireccionamiento a `login.html` después del registro

### 2. **Archivo: `php/auth/login.php`**
- ✓ Actualizado para trabajar con la tabla `usuarios_alborada`
- ✓ Usa campos: `Correo` y `Contraseña`
- ✓ Verificación de contraseña con `password_verify()`
- ✓ Gestión de sesiones
- ✓ Cookie de "Recordarme" (30 días)
- ✓ Respuesta JSON para AJAX

### 3. **Archivo: `php/config/database.php`**
- ✓ Configuración de conexión a base de datos `alborada`
- ✓ Usuario: `root` (sin contraseña)
- ✓ Host: `localhost`

### 4. **Archivo: `cuenta.html`** (Página de Registro)
- ✓ Campos del formulario: Nombre Completo, Email, Teléfono, Contraseña
- ✓ Validación de contraseñas coincidentes
- ✓ Toggle para mostrar/ocultar contraseña
- ✓ Aceptación de términos y condiciones
- ✓ AJAX para enviar datos a `php/auth/register.php`

### 5. **Archivo: `login.html`** (Página de Login)
- ✓ Creado nuevo archivo para iniciar sesión
- ✓ Formulario con Email y Contraseña
- ✓ Modal de recuperación de contraseña
- ✓ AJAX para enviar datos a `php/auth/login.php`
- ✓ Enlaces hacia registro y página principal

---

## 🗄️ Estructura de Base de Datos

```sql
CREATE TABLE `usuarios_alborada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Correo` varchar(100) NOT NULL UNIQUE,
  `Contraseña` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## 🚀 Flujo de Funcionamiento

### Registro:
1. Usuario llena formulario en `cuenta.html`
2. Valida contraseñas y términos en el navegador
3. Envía datos a `php/auth/register.php` vía AJAX
4. PHP valida email único y hash la contraseña
5. Inserta en tabla `usuarios_alborada`
6. Redirige a `login.html`

### Login:
1. Usuario llena formulario en `login.html`
2. Envía credenciales a `php/auth/login.php` vía AJAX
3. PHP busca email en `usuarios_alborada`
4. Verifica contraseña con `password_verify()`
5. Crea sesión $_SESSION
6. Redirige al dashboard

---

## 🔒 Seguridad

✅ **Hash de Contraseñas**: `password_hash()` con `PASSWORD_DEFAULT`
✅ **CSRF Protection**: Usar tokens en producción
✅ **SQL Injection Protection**: Prepared statements con PDO
✅ **Email Validation**: `FILTER_VALIDATE_EMAIL`
✅ **Session Management**: Sesiones PHP

---

## 📝 URLs Importantes

- 📄 Registro: `http://localhost/http%2023/cuenta.html`
- 📄 Login: `http://localhost/http%2023/login.html`
- 🔌 API Registro: `http://localhost/http%2023/php/auth/register.php`
- 🔌 API Login: `http://localhost/http%2023/php/auth/login.php`

---

## ⚠️ Notas Importantes

1. La base de datos debe estar creada: `alborada`
2. La tabla `usuarios_alborada` debe existir
3. Usuario MySQL: `root` sin contraseña (ajusta si es diferente)
4. Los campos de la tabla son CASE SENSITIVE: `Correo` y `Contraseña`
5. Las contraseñas se almacenan hasheadas, no en texto plano

---

## 🧪 Prueba Rápida

1. Abre `cuenta.html` en tu navegador
2. Completa el formulario con:
   - Nombre: Tu nombre
   - Email: test@ejemplo.com
   - Teléfono: 1234567890
   - Contraseña: password123
3. Haz clic en "Crear Cuenta"
4. Si es exitoso, irás a `login.html`
5. Inicia sesión con el email y contraseña registrados

---

**✨ ¡Sistema completamente conectado a la base de datos!**
